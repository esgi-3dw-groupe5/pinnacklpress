<?php
/**
 * This file is an example of the config file necessary to connect to the database
 * @var array
 */
$config = array(
'db_host' => '',
'db_name' => '',
'db_login' => '',
'db_password' => '',
);