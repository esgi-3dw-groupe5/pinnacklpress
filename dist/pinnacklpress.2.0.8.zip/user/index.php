<?php

include '../nimda/index.php';